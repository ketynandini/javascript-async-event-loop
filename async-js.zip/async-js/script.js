let output = "";

function tampilkan(teks) {
  console.log(teks);
  output += teks + "<br>";
  document.getElementById("output").innerHTML = output;
}

// STEP 1
function step1() {
  tampilkan("STEP 1:");
  tampilkan("A");
  tampilkan("B");
  tampilkan("C");
}

// STEP 2
function step2() {
  tampilkan("STEP 2:");
  tampilkan("Start");

  setTimeout(() => {
    tampilkan("Timeout");
  }, 0);

  tampilkan("End");
}

// STEP 3
function step3() {
  tampilkan("STEP 3:");
  tampilkan("Start");

  Promise.resolve().then(() => {
    tampilkan("Promise");
  });

  tampilkan("End");
}

// STEP 4
function step4() {
  tampilkan("STEP 4:");
  tampilkan("Start");

  setTimeout(() => {
    tampilkan("Timeout");
  }, 0);

  Promise.resolve().then(() => {
    tampilkan("Promise");
  });

  tampilkan("End");
}

// STEP 5
function step5() {
  tampilkan("STEP 5:");

  async function test() {
    tampilkan("1");
    await Promise.resolve();
    tampilkan("2");
  }

  tampilkan("3");
  test();
  tampilkan("4");
}

// STEP 6
function step6() {
  tampilkan("STEP 6:");

  tampilkan("A");

  setTimeout(() => {
    tampilkan("B");
  }, 0);

  Promise.resolve().then(() => {
    tampilkan("C");
  });

  tampilkan("D");
}

// 🔥 JALANKAN BERURUTAN (pakai delay)
step1();

setTimeout(step2, 500);
setTimeout(step3, 1000);
setTimeout(step4, 1500);
setTimeout(step5, 2000);
setTimeout(step6, 2500);
